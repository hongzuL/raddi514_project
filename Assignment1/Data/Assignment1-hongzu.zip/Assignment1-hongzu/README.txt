The code is written on matlab R2018a.
To run the program, simply open As1.m with matlab and click run button. And in the console, choose 1 or 2 for dataset selection.
The program should plot one image with four subimages, and print SNR and contrast information at the console.